"""
Database package for comprehensive GitHub integration.
"""

# Import from the main database module
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

# Import the main database functions
try:
    from ..database import connect_to_mongo, close_mongo_connection, get_database, get_db_health
except ImportError:
    # Fallback imports
    connect_to_mongo = None
    close_mongo_connection = None
    get_database = None
    get_db_health = None

from .schema_manager import SchemaManager, initialize_database_schema, get_database_health
from .migrations import DatabaseMigrator, run_full_migration, cleanup_database, validate_database_integrity
from .utils import DatabaseUtils, ensure_indexes_exist, convert_object_ids, validate_document_schema

__all__ = [
    "connect_to_mongo", "close_mongo_connection", "get_database", "get_db_health",
    "SchemaManager", "initialize_database_schema", "get_database_health",
    "DatabaseMigrator", "run_full_migration", "cleanup_database", "validate_database_integrity",
    "DatabaseUtils", "ensure_indexes_exist", "convert_object_ids", "validate_document_schema"
]