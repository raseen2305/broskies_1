"""
Multi-Database Connection Manager for Database Restructuring
Handles connections to seven separate MongoDB databases with proper user type differentiation
"""

from motor.motor_asyncio import AsyncIOMotorClient
from app.core.config import settings
import logging
import asyncio
import os
import time
from typing import Optional, Dict, Any, Literal
from enum import Enum

logger = logging.getLogger(__name__)

class DatabaseType(Enum):
    """Enum for different database types in the multi-database architecture"""
    EXTERNAL_USERS = "external_users"
    RASEEN_TEMP_USER = "raseen_temp_user"
    RASEEN_MAIN_USER = "raseen_main_user"
    RASEEN_MAIN_HR = "raseen_main_hr"
    SRIE_MAIN_USER = "srie_main_user"
    SRIE_MAIN_HR = "srie_main_hr"

class MultiDatabaseManager:
    """Manages connections to multiple MongoDB databases with proper error handling and retry logic"""
    
    def __init__(self):
        self.clients: Dict[DatabaseType, Optional[AsyncIOMotorClient]] = {}
        self.databases: Dict[DatabaseType, Optional[Any]] = {}
        self.last_activity: Dict[DatabaseType, float] = {}
        self.connection_timeout = 300  # 5 minutes timeout
        self.max_retries = 3
        self.is_connecting: Dict[DatabaseType, bool] = {}
        self._connection_locks: Dict[DatabaseType, asyncio.Lock] = {}
        
        # Initialize locks for each database type
        for db_type in DatabaseType:
            self._connection_locks[db_type] = asyncio.Lock()
            self.is_connecting[db_type] = False
            self.last_activity[db_type] = 0

    def _get_database_url(self, db_type: DatabaseType) -> str:
        """Get the appropriate database URL from environment variables"""
        url_mapping = {
            DatabaseType.EXTERNAL_USERS: "EXTERNAL_USERS_DB_URL",
            DatabaseType.RASEEN_TEMP_USER: "RASEEN_TEMP_USER_DB_URL", 
            DatabaseType.RASEEN_MAIN_USER: "RASEEN_MAIN_USER_DB_URL",
            DatabaseType.RASEEN_MAIN_HR: "RASEEN_MAIN_HR_DB_URL",
            DatabaseType.SRIE_MAIN_USER: "SRIE_MAIN_USER_DB_URL",
            DatabaseType.SRIE_MAIN_HR: "SRIE_MAIN_HR_DB_URL"
        }
        
        env_var = url_mapping[db_type]
        url = os.getenv(env_var)
        
        if not url:
            raise ValueError(f"Environment variable {env_var} not found for database {db_type.value}")
        
        return url

    def _get_connection_config(self, db_type: DatabaseType) -> Dict[str, Any]:
        """Get optimized connection configuration for each database type"""
        url = self._get_database_url(db_type)
        
        # Extract database name from URL
        database_name = db_type.value
        
        # Optimized connection parameters with error handling
        connection_params = {
            "serverSelectionTimeoutMS": 30000,
            "connectTimeoutMS": 30000,
            "socketTimeoutMS": 45000,
            "maxPoolSize": 5,  # Reasonable pool size for each database
            "minPoolSize": 0,
            "retryWrites": True,
            "retryReads": True,
            "maxIdleTimeMS": 60000,
            "heartbeatFrequencyMS": 30000,
            "tlsAllowInvalidCertificates": False,
        }
        
        return {
            "url": url,
            "params": connection_params,
            "database_name": database_name
        }

    async def get_database(self, db_type: DatabaseType):
        """Get database connection for specified database type with lazy loading"""
        # Fast path: return existing valid connection
        if (self.databases.get(db_type) is not None and 
            time.time() - self.last_activity.get(db_type, 0) < self.connection_timeout):
            self.last_activity[db_type] = time.time()
            return self.databases[db_type]
        
        # Slow path: need to check/establish connection
        if (self.databases.get(db_type) is None or 
            await self._is_connection_stale(db_type)):
            async with self._connection_locks[db_type]:
                # Double-check after acquiring lock
                if (self.databases.get(db_type) is None or 
                    await self._is_connection_stale(db_type)):
                    logger.info(f"🔐 Establishing connection to {db_type.value} database...")
                    await self._connect_to_database(db_type)
        
        # Update last activity timestamp
        self.last_activity[db_type] = time.time()
        return self.databases.get(db_type)

    async def _is_connection_stale(self, db_type: DatabaseType) -> bool:
        """Check if the database connection is stale"""
        client = self.clients.get(db_type)
        if client is None or self.databases.get(db_type) is None:
            return True
        
        # Check if connection has been idle too long
        if time.time() - self.last_activity.get(db_type, 0) > self.connection_timeout:
            logger.info(f"Database connection to {db_type.value} idle timeout reached, will reconnect")
            return True
        
        # Quick ping test for connection health
        try:
            await asyncio.wait_for(client.admin.command('ping'), timeout=2.0)
            return False
        except Exception as e:
            logger.warning(f"Database connection health check failed for {db_type.value}: {e}")
            return True

    async def _connect_to_database(self, db_type: DatabaseType):
        """Connect to a specific database with retry logic"""
        if self.is_connecting[db_type]:
            # Wait for existing connection attempt
            max_wait = 30
            wait_count = 0
            while self.is_connecting[db_type] and wait_count < max_wait:
                await asyncio.sleep(0.1)
                wait_count += 1
            return

        self.is_connecting[db_type] = True
        
        try:
            logger.info(f"🔗 Establishing connection to {db_type.value}...")
            
            # Close any existing stale connections
            await self._cleanup_stale_connection(db_type)
            
            # Try connection with exponential backoff
            success = await self._connect_with_retry(db_type)
            
            if success:
                logger.info(f"✅ Connected to {db_type.value} database")
                self.last_activity[db_type] = time.time()
            else:
                logger.error(f"❌ Failed to connect to {db_type.value} after retries")
                raise Exception(f"Failed to connect to {db_type.value} database")
                
        except Exception as e:
            logger.error(f"❌ Error connecting to {db_type.value}: {e}")
            raise
        finally:
            self.is_connecting[db_type] = False

    async def _cleanup_stale_connection(self, db_type: DatabaseType):
        """Clean up stale connection for specific database"""
        client = self.clients.get(db_type)
        if client:
            try:
                client.close()
            except Exception as e:
                logger.debug(f"Error closing stale connection for {db_type.value}: {e}")
            finally:
                self.clients[db_type] = None
                self.databases[db_type] = None

    async def _connect_with_retry(self, db_type: DatabaseType) -> bool:
        """Connect to database with exponential backoff retry logic"""
        base_delay = 1
        
        for attempt in range(self.max_retries):
            try:
                logger.info(f"Connection attempt {attempt + 1}/{self.max_retries} for {db_type.value}")
                
                # Get connection configuration
                config = self._get_connection_config(db_type)
                
                # Log connection details for debugging (mask credentials)
                masked_url = self._mask_credentials(config['url'])
                logger.info(f"Connecting to: {masked_url}")
                logger.info(f"Database: {config['database_name']}")
                
                # Create client with optimized settings
                client = AsyncIOMotorClient(
                    config["url"],
                    **config["params"]
                )
                
                # Test connection
                await asyncio.wait_for(
                    client.admin.command('ping'),
                    timeout=15.0
                )
                
                # Success! Set up the connection
                self.clients[db_type] = client
                self.databases[db_type] = client[config["database_name"]]
                
                logger.info(f"✅ Connected to {db_type.value}: {config['database_name']}")
                return True
                
            except Exception as e:
                error_msg = str(e) if str(e) else f"{type(e).__name__}: {repr(e)}"
                logger.warning(f"Connection attempt {attempt + 1} failed for {db_type.value}: {error_msg}")
                
                if attempt < self.max_retries - 1:
                    delay = base_delay * (2 ** attempt)
                    logger.info(f"Retrying {db_type.value} connection in {delay} seconds...")
                    await asyncio.sleep(delay)
                
                try:
                    if 'client' in locals():
                        client.close()
                except:
                    pass
        
        return False

    def _mask_credentials(self, url: str) -> str:
        """Mask credentials in URL for logging"""
        if "://" in url and "@" in url:
            protocol = url.split("://")[0]
            rest = url.split("://")[1]
            if "@" in rest:
                credentials = rest.split("@")[0]
                host_and_path = rest.split("@")[1]
                return f"{protocol}://***:***@{host_and_path}"
        return url

    async def safe_db_operation(self, db_type: DatabaseType, operation_func, 
                              fallback_result=None, operation_name="database operation"):
        """Safely execute database operations with enhanced error tracking and retry logic"""
        # Import here to avoid circular imports
        from app.services.error_diagnostic_system import (
            error_diagnostic_system, OperationType, ErrorSeverity
        )
        
        # Determine operation type from operation name
        operation_type = OperationType.FETCH
        if "stor" in operation_name.lower() or "insert" in operation_name.lower():
            operation_type = OperationType.STORE
        elif "updat" in operation_name.lower():
            operation_type = OperationType.UPDATE
        elif "migrat" in operation_name.lower():
            operation_type = OperationType.MIGRATE
        elif "delet" in operation_name.lower():
            operation_type = OperationType.DELETE
        
        async def enhanced_operation():
            database = await self.get_database(db_type)
            if database is None:
                raise Exception(f"Database {db_type.value} not available")
            
            # Execute the operation with timeout
            return await asyncio.wait_for(
                operation_func(database),
                timeout=30.0
            )
        
        try:
            return await error_diagnostic_system.execute_with_retry(
                operation_type=operation_type,
                database_name=db_type.value,
                operation_func=enhanced_operation,
                context={"operation_name": operation_name}
            )
        except Exception as e:
            # Log final failure and return fallback
            error_diagnostic_system.log_error(
                operation_type=operation_type,
                database_name=db_type.value,
                error_message=f"Operation failed after retries: {str(e)}",
                severity=ErrorSeverity.HIGH,
                context={"operation_name": operation_name, "fallback_used": True}
            )
            
            logger.warning(f"error in {operation_name} to {db_type.value}, using fallback: {str(e)}")
            return fallback_result

    async def get_external_db(self):
        """Get external users database"""
        return await self.get_database(DatabaseType.EXTERNAL_USERS)

    async def get_raseen_temp_db(self):
        """Get raseen temporary user database"""
        return await self.get_database(DatabaseType.RASEEN_TEMP_USER)

    async def get_raseen_main_db(self):
        """Get raseen main user database"""
        return await self.get_database(DatabaseType.RASEEN_MAIN_USER)

    async def get_raseen_hr_db(self):
        """Get raseen HR database"""
        return await self.get_database(DatabaseType.RASEEN_MAIN_HR)

    async def get_srie_main_db(self):
        """Get srie main user database (backup)"""
        return await self.get_database(DatabaseType.SRIE_MAIN_USER)

    async def get_srie_hr_db(self):
        """Get srie HR database (backup)"""
        return await self.get_database(DatabaseType.SRIE_MAIN_HR)

    async def close_all_connections(self):
        """Close all database connections"""
        for db_type in DatabaseType:
            client = self.clients.get(db_type)
            if client:
                try:
                    client.close()
                    logger.info(f"Disconnected from {db_type.value}")
                except Exception as e:
                    logger.warning(f"Error closing connection to {db_type.value}: {e}")
                finally:
                    self.clients[db_type] = None
                    self.databases[db_type] = None

    async def get_health_status(self) -> Dict[str, Any]:
        """Get health status of all database connections"""
        health_status = {
            "timestamp": time.time(),
            "databases": {},
            "overall_healthy": True
        }
        
        for db_type in DatabaseType:
            db_health = {
                "connected": False,
                "last_activity": self.last_activity.get(db_type, 0),
                "error": None
            }
            
            try:
                client = self.clients.get(db_type)
                if client:
                    await asyncio.wait_for(client.admin.command('ping'), timeout=5.0)
                    db_health["connected"] = True
                else:
                    db_health["error"] = "No client connection"
                    health_status["overall_healthy"] = False
                    
            except Exception as e:
                db_health["error"] = str(e)
                health_status["overall_healthy"] = False
            
            health_status["databases"][db_type.value] = db_health
        
        return health_status

    async def initialize_all_connections(self):
        """Initialize connections to all databases at startup"""
        logger.info("🚀 Initializing connections to all seven databases...")
        
        connection_tasks = []
        for db_type in DatabaseType:
            task = asyncio.create_task(self._connect_to_database(db_type))
            connection_tasks.append((db_type, task))
        
        # Wait for all connections with individual error handling
        results = {}
        for db_type, task in connection_tasks:
            try:
                await task
                results[db_type.value] = "✅ Connected"
            except Exception as e:
                results[db_type.value] = f"❌ Failed: {str(e)}"
                logger.error(f"Failed to connect to {db_type.value}: {e}")
        
        # Log summary
        logger.info("📊 Database Connection Summary:")
        for db_name, status in results.items():
            logger.info(f"  {db_name}: {status}")
        
        successful_connections = sum(1 for status in results.values() if "✅" in status)
        total_connections = len(results)
        
        if successful_connections == total_connections:
            logger.info(f"🎉 All {total_connections} database connections established successfully!")
        else:
            logger.warning(f"⚠️  {successful_connections}/{total_connections} database connections successful")
        
        return results

# Global instance
multi_db_manager = MultiDatabaseManager()

# Convenience functions for backward compatibility and ease of use
async def get_external_users_db():
    """Get external users database"""
    return await multi_db_manager.get_external_db()

async def get_raseen_temp_user_db():
    """Get raseen temporary user database"""
    return await multi_db_manager.get_raseen_temp_db()

async def get_raseen_main_user_db():
    """Get raseen main user database"""
    return await multi_db_manager.get_raseen_main_db()

async def get_raseen_main_hr_db():
    """Get raseen HR database"""
    return await multi_db_manager.get_raseen_hr_db()

async def get_srie_main_user_db():
    """Get srie main user database (backup)"""
    return await multi_db_manager.get_srie_main_db()

async def get_srie_main_hr_db():
    """Get srie HR database (backup)"""
    return await multi_db_manager.get_srie_hr_db()

async def initialize_multi_database_connections():
    """Initialize all database connections"""
    return await multi_db_manager.initialize_all_connections()

async def close_multi_database_connections():
    """Close all database connections"""
    await multi_db_manager.close_all_connections()

async def get_multi_database_health():
    """Get health status of all databases"""
    return await multi_db_manager.get_health_status()