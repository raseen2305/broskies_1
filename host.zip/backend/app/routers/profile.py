"""
Profile and Regional Comparison API Endpoints
"""

from fastapi import APIRouter, HTTPException, Depends, status, Query
from typing import List, Dict, Any, Optional
from datetime import datetime
import logging
from statistics import mean

from app.models.profile import (
    UserProfile, UserProfileCreate, UserProfileUpdate, UserOverallDetails,
    RegionalScore, UniversityScore,
    COUNTRIES, INDIAN_STATES, POPULAR_UNIVERSITIES, get_indian_colleges
)
from app.models.user import User
from app.core.security import get_current_user_token
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials


logger = logging.getLogger(__name__)
router = APIRouter()
security = HTTPBearer(auto_error=False)

# Flag to track if indexes have been ensured
_indexes_ensured = False

async def ensure_profile_indexes(db):
    """Ensure required indexes exist on user_profiles collection"""
    global _indexes_ensured
    
    if _indexes_ensured:
        return
    
    try:
        # Create index on github_username for fast lookups (used in external ranking checks)
        await db.user_profiles.create_index("github_username")
        logger.info("✅ Ensured index on github_username field")
        _indexes_ensured = True
    except Exception as e:
        logger.warning(f"Failed to ensure indexes: {e}")
        # Don't fail if index creation fails (it might already exist)

async def get_optional_current_user(credentials: Optional[HTTPAuthorizationCredentials] = Depends(security)) -> Optional[Dict[str, Any]]:
    """Get current user token if available, otherwise return None"""
    if not credentials:
        return None
    
    try:
        from app.core.security import verify_token
        payload = verify_token(credentials.credentials)
        user_id = payload.get("sub")
        user_type = payload.get("user_type")
        github_username = payload.get("github_username", "")
        
        if not user_id:
            return None
        
        return {
            "user_id": user_id,
            "user_type": user_type,
            "github_username": github_username,
            "token_payload": payload
        }
    except Exception as e:
        logger.warning(f"Optional auth failed: {e}")
        return None

def convert_objectid_to_string(doc):
    """Convert MongoDB ObjectId to string for Pydantic validation"""
    if doc and "_id" in doc:
        doc["_id"] = str(doc["_id"])
    return doc

def generate_university_short(university: str) -> str:
    """
    Generate short university identifier
    Examples:
    - "MIT" → "mit"
    - "Stanford University" → "stanford"
    - "Indian Institute of Technology, Madras" → "iit-madras"
    """
    # Remove common words
    remove_words = ["university", "of", "the", "institute", "technology", "college"]
    words = university.lower().split()
    filtered = [w.strip(",") for w in words if w.strip(",") not in remove_words]
    
    # Handle acronyms (short uppercase words)
    if filtered and len(filtered[0]) <= 4:
        return filtered[0].lower()
    
    # Join with hyphens, limit to 3 words
    return "-".join(filtered[:3]) if filtered else university.lower()[:20]

def generate_region(nationality: str, state: str) -> str:
    """
    Generate region identifier for comparison grouping
    Examples:
    - "US", "California" → "US-California"
    - "IN", "Tamil Nadu" → "IN-Tamil Nadu"
    """
    return f"{nationality}-{state}"

@router.post("/setup", response_model=UserProfile)
async def setup_user_profile(
    profile_data: UserProfileCreate,
    current_user_token: dict = Depends(get_current_user_token)
):
    """Create or update user profile for regional/university comparison"""
    try:
        # Get database connection
        from app.db_connection import get_database as get_db_connection
        db = await get_db_connection()
        
        # Ensure indexes exist
        if db is not None:
            await ensure_profile_indexes(db)
        
        user_id = current_user_token["user_id"]
        github_username = current_user_token.get("github_username", "")
        
        # If github_username not in token, try to get it from users collection
        if not github_username and db is not None:
            from bson import ObjectId
            try:
                user_doc = await db.users.find_one({"_id": ObjectId(user_id)})
                if user_doc:
                    github_username = user_doc.get("github_username", "")
                    logger.info(f"Retrieved github_username from users collection: {github_username}")
            except Exception as e:
                logger.warning(f"Could not retrieve github_username from users collection: {e}")
        
        logger.info(f"Profile setup for user_id: {user_id}, github_username: {github_username}")
        
        # Check if profile already exists
        existing_profile = None
        if db is not None:
            existing_profile = await db.user_profiles.find_one({"user_id": user_id})
        
        profile_dict = profile_data.dict()
        
        # Auto-generate university_short and region if not provided
        if not profile_dict.get("university_short"):
            profile_dict["university_short"] = generate_university_short(profile_dict["university"])
        
        if not profile_dict.get("region"):
            profile_dict["region"] = generate_region(profile_dict["nationality"], profile_dict["state"])
        
        profile_dict.update({
            "user_id": user_id,
            "github_username": github_username,
            "updated_at": datetime.utcnow()
        })
        
        if existing_profile:
            # Update existing profile
            if db is not None:
                await db.user_profiles.update_one(
                    {"user_id": user_id},
                    {"$set": profile_dict}
                )
                updated_profile = await db.user_profiles.find_one({"user_id": user_id})
                profile = UserProfile(**convert_objectid_to_string(updated_profile))
            else:
                # For testing without database
                profile = UserProfile(**profile_dict)
        else:
            # Create new profile
            profile_dict["created_at"] = datetime.utcnow()
            
            if db is not None:
                result = await db.user_profiles.insert_one(profile_dict)
                new_profile = await db.user_profiles.find_one({"_id": result.inserted_id})
                profile = UserProfile(**convert_objectid_to_string(new_profile))
            else:
                # For testing without database
                profile = UserProfile(**profile_dict)
        
        # Trigger automatic ranking sync after profile creation
        ranking_sync_triggered = False
        ranking_sync_status = None
        
        try:
            logger.info(f"🎯 Triggering automatic ranking sync after profile setup for user: {user_id}")
            
            from app.services.ranking_service import RankingService
            from app.services.score_sync_service import ScoreSyncService
            
            # Initialize ranking services
            ranking_service = RankingService(db)
            sync_service = ScoreSyncService(db, ranking_service)
            
            # Attempt to sync scores and calculate rankings
            sync_result = await sync_service.sync_user_score(user_id)
            ranking_sync_triggered = True
            
            if sync_result.get("success"):
                ranking_sync_status = "success"
                logger.info(f"✅ Rankings calculated successfully for user: {user_id}")
                logger.info(f"   - ACID Score: {sync_result.get('acid_score', 0)}")
                logger.info(f"   - Regional updated: {sync_result.get('regional_updated', False)}")
                logger.info(f"   - University updated: {sync_result.get('university_updated', False)}")
            else:
                ranking_sync_status = "pending"
                error_code = sync_result.get("error_code")
                
                if error_code == "NO_SCAN_RESULTS":
                    logger.info(f"ℹ️ User {user_id} has no scan results yet. Rankings will be calculated after first scan.")
                elif error_code == "NO_PROFILE":
                    logger.warning(f"⚠️ Profile check failed for user {user_id} (this shouldn't happen)")
                else:
                    logger.warning(f"⚠️ Ranking sync failed for user {user_id}: {sync_result.get('error')}")
                
        except Exception as sync_error:
            logger.error(f"❌ Error triggering ranking sync after profile setup: {sync_error}")
            ranking_sync_triggered = True
            ranking_sync_status = "error"
            # Don't fail profile creation if ranking sync fails
        
        logger.info(f"Profile setup completed for user: {user_id}")
        logger.info(f"   - Ranking sync triggered: {ranking_sync_triggered}")
        logger.info(f"   - Ranking sync status: {ranking_sync_status}")
        
        return profile
        
    except Exception as e:
        logger.error(f"Failed to setup user profile: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to setup profile: {str(e)}"
        )

@router.get("/me", response_model=UserProfile)
async def get_my_profile(
    current_user_token: dict = Depends(get_current_user_token)
):
    """Get current user's profile"""
    try:
        # Get database connection
        from app.db_connection import get_database as get_db_connection
        db = await get_db_connection()
        
        user_id = current_user_token["user_id"]
        
        if db is not None:
            profile_doc = await db.user_profiles.find_one({"user_id": user_id})
            if not profile_doc:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Profile not found. Please complete profile setup first."
                )
            
            profile = UserProfile(**convert_objectid_to_string(profile_doc))
        else:
            # For testing without database
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Profile not found"
            )
        
        return profile
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get user profile: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get profile: {str(e)}"
        )

@router.put("/update", response_model=UserProfile)
async def update_user_profile(
    profile_updates: UserProfileUpdate,
    current_user_token: dict = Depends(get_current_user_token)
):
    """Update user profile"""
    try:
        # Get database connection
        from app.db_connection import get_database as get_db_connection
        db = await get_db_connection()
        
        user_id = current_user_token["user_id"]
        
        # Get existing profile
        if db is not None:
            existing_profile = await db.user_profiles.find_one({"user_id": user_id})
            if not existing_profile:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Profile not found. Please complete profile setup first."
                )
        
        # Update only provided fields
        update_data = {k: v for k, v in profile_updates.dict().items() if v is not None}
        update_data["updated_at"] = datetime.utcnow()
        
        if db is not None:
            await db.user_profiles.update_one(
                {"user_id": user_id},
                {"$set": update_data}
            )
            
            updated_profile = await db.user_profiles.find_one({"user_id": user_id})
            profile = UserProfile(**convert_objectid_to_string(updated_profile))
        else:
            # For testing without database
            profile = UserProfile(**update_data)
        

        
        logger.info(f"Profile updated for user: {user_id}")
        return profile
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to update user profile: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update profile: {str(e)}"
        )





@router.get("/status")
async def get_profile_status(
    current_user_token: dict = Depends(get_current_user_token)
):
    """Check if user has completed profile setup"""
    try:
        # Get database connection
        from app.db_connection import get_database as get_db_connection
        db = await get_db_connection()
        
        user_id = current_user_token["user_id"]
        
        if db is not None:
            profile = await db.user_profiles.find_one({"user_id": user_id})
            has_profile = profile is not None
        else:
            has_profile = False
        
        return {
            "has_profile": has_profile,
            "user_id": user_id
        }
        
    except Exception as e:
        logger.error(f"Failed to check profile status: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to check profile status: {str(e)}"
        )

@router.get("/data/countries")
async def get_countries():
    """Get list of supported countries"""
    return {"countries": list(COUNTRIES.keys())}

@router.get("/me/public")
async def get_profile_public(
    user_token: Optional[Dict[str, Any]] = Depends(get_optional_current_user)
):
    """Get user profile (public endpoint for testing)"""
    if not user_token:
        return {
            "has_profile": False,
            "profile": None,
            "message": "Authentication required for profile access"
        }
    
    try:
        # Get database connection
        from app.db_connection import get_database as get_db_connection
        db = await get_db_connection()
        
        user_id = user_token["user_id"]
        
        if db is not None:
            profile_doc = await db.user_profiles.find_one({"user_id": user_id})
            if profile_doc:
                profile = UserProfile(**convert_objectid_to_string(profile_doc))
                return {
                    "has_profile": True,
                    "profile": profile
                }
        
        return {
            "has_profile": False,
            "profile": None,
            "message": "Profile not found"
        }
        
    except Exception as e:
        logger.error(f"Failed to get profile: {e}")
        return {
            "has_profile": False,
            "profile": None,
            "error": str(e)
        }

@router.post("/sync-score/public")
async def sync_score_public(
    user_token: Optional[Dict[str, Any]] = Depends(get_optional_current_user)
):
    """Sync user score (public endpoint for testing)"""
    if not user_token:
        return {
            "success": False,
            "message": "Authentication required for score sync"
        }
    
    try:
        # Get database connection
        from app.db_connection import get_database as get_db_connection
        db = await get_db_connection()
        
        user_id = user_token["user_id"]
        
        if db is not None:
            # Try to find scan results
            scan_results = await db.scan_results.find_one(
                {"userId": user_id},
                sort=[("lastScanDate", -1)]
            )
            
            if scan_results:

                
                return {
                    "success": True,
                    "message": "Score synced successfully",
                    "overall_score": scan_results.get("overallScore", 0.0)
                }
        
        return {
            "success": False,
            "message": "No scan results found"
        }
        
    except Exception as e:
        logger.error(f"Failed to sync score: {e}")
        return {
            "success": False,
            "message": str(e)
        }

@router.get("/data/states")
async def get_states(country: str = Query("IN", description="Country code")):
    """Get list of states for a country"""
    if country == "IN":
        return {"states": INDIAN_STATES}
    else:
        return {"states": []}

@router.get("/data/universities")
async def get_universities():
    """Get list of Indian colleges and universities (optimized with lazy loading)"""
    return {"universities": get_indian_colleges()}

@router.post("/sync-score")
async def sync_user_score(
    current_user_token: dict = Depends(get_current_user_token)
):
    """Sync user's latest score with ranking system"""
    try:
        # Get database connection
        from app.db_connection import get_database as get_db_connection
        from app.services.ranking_service import RankingService
        from app.services.score_sync_service import ScoreSyncService
        
        db = await get_db_connection()
        user_id = current_user_token["user_id"]
        github_username = current_user_token.get("github_username", "")
        
        if db is None:
            return {"message": "Score sync completed (test mode)"}
        
        # Get user's latest scan results and update overall details
        scan_results = await db.scan_results.find_one(
            {"userId": user_id},
            sort=[("lastScanDate", -1)]
        )
        
        if scan_results:
            # Update overall details
            overall_details = {
                "user_id": user_id,
                "name": scan_results.get("userInfo", {}).get("name", ""),
                "github_username": github_username,
                "repositories_count": scan_results.get("repositoryCount", 0),
                "overall_score": scan_results.get("overallScore", 0.0),
                "hybrid_score": scan_results.get("overallScore", 0.0),  # Alias for compatibility
                "acid_scores": scan_results.get("acid_scores", {}),
                "account_details": {
                    "followers": scan_results.get("githubProfile", {}).get("followers", 0),
                    "following": scan_results.get("githubProfile", {}).get("following", 0),
                    "public_repos": scan_results.get("repositoryCount", 0),
                    "total_stars": scan_results.get("repositoryOverview", {}).get("total_stars", 0),
                    "total_forks": scan_results.get("repositoryOverview", {}).get("total_forks", 0)
                },
                "last_scan_date": datetime.fromisoformat(scan_results.get("lastScanDate", "").replace("Z", "+00:00")),
                "updated_at": datetime.utcnow()
            }
            
            await db.user_overall_details.update_one(
                {"user_id": user_id},
                {"$set": overall_details},
                upsert=True
            )
        
        # Use ScoreSyncService to sync scores and update rankings
        ranking_service = RankingService(db)
        sync_service = ScoreSyncService(db, ranking_service)
        
        sync_result = await sync_service.sync_user_score(user_id)
        
        if not sync_result["success"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=sync_result.get("error", "Failed to sync score")
            )
        
        return {
            "message": "Score synced successfully",
            "overall_score": sync_result.get("acid_score", 0.0),
            "regional_updated": sync_result.get("regional_updated", False),
            "university_updated": sync_result.get("university_updated", False)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to sync user score: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to sync score: {str(e)}"
        )