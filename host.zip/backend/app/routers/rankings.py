"""
Rankings API Endpoints for Regional and University Comparisons
"""

from fastapi import APIRouter, HTTPException, Depends, status, Query
from typing import Dict, Any, Optional, List
from datetime import datetime
import logging

from app.core.security import get_current_user_token
from app.services.ranking_service import RankingService
from app.services.score_sync_service import ScoreSyncService

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("")
async def get_rankings(
    current_user_token: dict = Depends(get_current_user_token)
):
    """
    Get both regional and university rankings for the current user
    
    Returns:
        Dictionary with regional and university ranking information
    """
    try:
        # Get database connection
        from app.db_connection import get_database
        db = await get_database()
        
        if db is None:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Database connection unavailable"
            )
        
        user_id = current_user_token["user_id"]
        
        # Get rankings from user_rankings collection
        ranking = await db.user_rankings.find_one({"user_id": user_id})
        
        if not ranking:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Rankings not available. Please complete a repository scan first."
            )
        
        # Check if rankings have been calculated
        if not ranking.get("regional_rank") or not ranking.get("university_rank"):
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Rankings are being calculated. Please wait a moment and try again."
            )
        
        # Format response to match frontend expectations
        response = {
            "regional_percentile_text": f"Top {ranking['regional_percentile']:.1f}% in {ranking['region']}",
            "university_percentile_text": f"Top {ranking['university_percentile']:.1f}% in {ranking['university']}",
            "regional_ranking": {
                "rank_in_region": ranking["regional_rank"],
                "total_users_in_region": ranking["regional_total_users"],
                "percentile_region": ranking["regional_percentile"]
            },
            "university_ranking": {
                "rank_in_university": ranking["university_rank"],
                "total_users_in_university": ranking["university_total_users"],
                "percentile_university": ranking["university_percentile"]
            }
        }
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get rankings: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get rankings: {str(e)}"
        )


@router.get("/detailed")
async def get_detailed_rankings(
    type: str = Query(..., description="Type of ranking: 'regional' or 'university'"),
    current_user_token: dict = Depends(get_current_user_token)
):
    """
    Get detailed ranking statistics for regional or university comparison
    
    Args:
        type: Type of ranking ('regional' or 'university')
    
    Returns:
        Detailed ranking statistics with trend data
    """
    try:
        # Validate type parameter
        if type not in ["regional", "university"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Type must be 'regional' or 'university'"
            )
        
        # Get database connection
        from app.db_connection import get_database
        db = await get_database()
        
        if db is None:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Database connection unavailable"
            )
        
        user_id = current_user_token["user_id"]
        
        # Get ranking service
        ranking_service = RankingService(db)
        
        # Get ranking based on type
        if type == "regional":
            ranking = await ranking_service.get_regional_ranking(user_id)
            if not ranking:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Regional ranking not found"
                )
            
            comparison_context = ranking["region"]
            
        else:  # university
            ranking = await ranking_service.get_university_ranking(user_id)
            if not ranking:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="University ranking not found"
                )
            
            comparison_context = ranking["university_short"]
        
        # Format detailed response
        response = {
            "rank_position": ranking["rank_position"],
            "total_users": ranking.get("total_users_in_region") or ranking.get("total_users_in_university"),
            "percentile_score": ranking["percentile_score"],
            "acid_score": ranking["acid_score"],
            "comparison_context": comparison_context,
            "last_updated": ranking.get("last_updated", datetime.utcnow()).isoformat(),
            "trend_data": []  # TODO: Implement historical trend tracking
        }
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get detailed rankings: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get detailed rankings: {str(e)}"
        )


@router.post("/sync-score")
async def sync_score(
    acid_score: Optional[float] = Query(None, description="Optional ACID score (fetched automatically if not provided)"),
    current_user_token: dict = Depends(get_current_user_token)
):
    """
    Sync user's ACID score and trigger ranking updates
    
    Args:
        acid_score: Optional ACID score (if not provided, fetches from user_overall_details)
    
    Returns:
        Sync result with updated rankings
    """
    try:
        # Get database connection
        from app.db_connection import get_database
        db = await get_database()
        
        if db is None:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Database connection unavailable"
            )
        
        user_id = current_user_token["user_id"]
        
        # Validate acid_score if provided
        if acid_score is not None and (acid_score < 0 or acid_score > 100):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="ACID score must be between 0 and 100"
            )
        
        # Sync score
        ranking_service = RankingService(db)
        sync_service = ScoreSyncService(db, ranking_service)
        result = await sync_service.sync_user_score(user_id)
        
        if not result["success"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=result.get("error", "Failed to sync score")
            )
        
        return {
            "success": True,
            "message": "Score synced and rankings updated successfully",
            "acid_score": result.get("acid_score", 0.0),
            "regional_updated": result.get("regional_updated", False),
            "university_updated": result.get("university_updated", False)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to sync score: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to sync score: {str(e)}"
        )


@router.get("/leaderboard/regional")
async def get_regional_leaderboard(
    limit: int = Query(10, ge=1, le=50, description="Number of top users to return"),
    current_user_token: dict = Depends(get_current_user_token)
):
    """
    Get regional leaderboard showing top users in the same region
    
    Args:
        limit: Number of top users to return (1-50)
    
    Returns:
        List of top users in the region
    """
    try:
        # Get database connection
        from app.db_connection import get_database
        db = await get_database()
        
        if db is None:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Database connection unavailable"
            )
        
        user_id = current_user_token["user_id"]
        
        # Get user's region
        profile = await db.user_profiles.find_one({"user_id": user_id})
        if not profile:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Profile not found"
            )
        
        region = profile["region"]
        
        # Get leaderboard
        ranking_service = RankingService(db)
        leaderboard = await ranking_service.get_regional_leaderboard(region, limit)
        
        # Anonymize user data (remove user_id, keep only rank and score)
        anonymized_leaderboard = [
            {
                "rank_position": entry["rank_position"],
                "acid_score": entry["acid_score"],
                "percentile_score": entry["percentile_score"],
                "is_current_user": entry["user_id"] == user_id
            }
            for entry in leaderboard
        ]
        
        return {
            "region": region,
            "leaderboard": anonymized_leaderboard,
            "total_entries": len(anonymized_leaderboard)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get regional leaderboard: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get regional leaderboard: {str(e)}"
        )


@router.get("/leaderboard/university")
async def get_university_leaderboard(
    limit: int = Query(10, ge=1, le=50, description="Number of top users to return"),
    current_user_token: dict = Depends(get_current_user_token)
):
    """
    Get university leaderboard showing top users in the same university
    
    Args:
        limit: Number of top users to return (1-50)
    
    Returns:
        List of top users in the university
    """
    try:
        # Get database connection
        from app.db_connection import get_database
        db = await get_database()
        
        if db is None:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Database connection unavailable"
            )
        
        user_id = current_user_token["user_id"]
        
        # Get user's university
        profile = await db.user_profiles.find_one({"user_id": user_id})
        if not profile:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Profile not found"
            )
        
        university_short = profile["university_short"]
        
        # Get leaderboard
        ranking_service = RankingService(db)
        leaderboard = await ranking_service.get_university_leaderboard(university_short, limit)
        
        # Anonymize user data (remove user_id, keep only rank and score)
        anonymized_leaderboard = [
            {
                "rank_position": entry["rank_position"],
                "acid_score": entry["acid_score"],
                "percentile_score": entry["percentile_score"],
                "is_current_user": entry["user_id"] == user_id
            }
            for entry in leaderboard
        ]
        
        return {
            "university_short": university_short,
            "leaderboard": anonymized_leaderboard,
            "total_entries": len(anonymized_leaderboard)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get university leaderboard: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get university leaderboard: {str(e)}"
        )


@router.get("/stats/regional")
async def get_regional_stats(
    current_user_token: dict = Depends(get_current_user_token)
):
    """
    Get regional statistics and insights
    
    Returns:
        Regional statistics including distribution and averages
    """
    try:
        # Get database connection
        from app.db_connection import get_database
        db = await get_database()
        
        if db is None:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Database connection unavailable"
            )
        
        user_id = current_user_token["user_id"]
        
        # Get user's region
        profile = await db.user_profiles.find_one({"user_id": user_id})
        if not profile:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Profile not found"
            )
        
        region = profile["region"]
        
        # Get all scores in region
        regional_scores = await db.regional_scores.find({"region": region}).to_list(None)
        
        if not regional_scores:
            return {
                "region": region,
                "total_users": 0,
                "average_score": 0,
                "median_score": 0,
                "min_score": 0,
                "max_score": 0
            }
        
        scores = [s["acid_score"] for s in regional_scores]
        scores.sort()
        
        # Calculate statistics
        total_users = len(scores)
        average_score = sum(scores) / total_users
        median_score = scores[total_users // 2] if total_users > 0 else 0
        min_score = min(scores)
        max_score = max(scores)
        
        return {
            "region": region,
            "total_users": total_users,
            "average_score": round(average_score, 2),
            "median_score": round(median_score, 2),
            "min_score": round(min_score, 2),
            "max_score": round(max_score, 2)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get regional stats: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get regional stats: {str(e)}"
        )


@router.get("/stats/university")
async def get_university_stats(
    current_user_token: dict = Depends(get_current_user_token)
):
    """
    Get university statistics and insights
    
    Returns:
        University statistics including distribution and averages
    """
    try:
        # Get database connection
        from app.db_connection import get_database
        db = await get_database()
        
        if db is None:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Database connection unavailable"
            )
        
        user_id = current_user_token["user_id"]
        
        # Get user's university
        profile = await db.user_profiles.find_one({"user_id": user_id})
        if not profile:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Profile not found"
            )
        
        university_short = profile["university_short"]
        
        # Get all scores in university
        university_scores = await db.university_scores.find(
            {"university_short": university_short}
        ).to_list(None)
        
        if not university_scores:
            return {
                "university_short": university_short,
                "total_users": 0,
                "average_score": 0,
                "median_score": 0,
                "min_score": 0,
                "max_score": 0
            }
        
        scores = [s["acid_score"] for s in university_scores]
        scores.sort()
        
        # Calculate statistics
        total_users = len(scores)
        average_score = sum(scores) / total_users
        median_score = scores[total_users // 2] if total_users > 0 else 0
        min_score = min(scores)
        max_score = max(scores)
        
        return {
            "university_short": university_short,
            "total_users": total_users,
            "average_score": round(average_score, 2),
            "median_score": round(median_score, 2),
            "min_score": round(min_score, 2),
            "max_score": round(max_score, 2)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get university stats: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get university stats: {str(e)}"
        )


@router.get("/check/{github_username}")
async def check_ranking_availability(
    github_username: str
):
    """
    Check if ranking data is available for a GitHub username (public endpoint for external scans)
    
    Args:
        github_username: GitHub username to check
    
    Returns:
        Dictionary indicating if ranking data exists and the ranking details if available
    """
    try:
        # Get database connection
        from app.db_connection import get_database
        db = await get_database()
        
        if db is None:
            return {
                "has_ranking_data": False,
                "message": "Database connection unavailable"
            }
        
        logger.info(f"Checking ranking availability for GitHub username: {github_username}")
        
        # Get ranking data from user_rankings collection (case-insensitive search)
        ranking = await db.user_rankings.find_one({"github_username": {"$regex": f"^{github_username}$", "$options": "i"}})
        
        if not ranking:
            logger.info(f"No ranking data found for GitHub username: {github_username}")
            return {
                "has_ranking_data": False,
                "message": "User has not set up a profile or completed a scan yet"
            }
        
        # Check if rankings have been calculated
        has_regional = ranking.get("regional_rank") is not None
        has_university = ranking.get("university_rank") is not None
        
        if not has_regional and not has_university:
            logger.info(f"Rankings not calculated yet for user: {github_username}")
            return {
                "has_ranking_data": False,
                "message": "Rankings are being calculated. Please try again in a moment."
            }
        
        # Prepare ranking data response
        response = {
            "has_ranking_data": True,
            "github_username": github_username,
            "profile": {
                "full_name": ranking.get("name"),
                "university": ranking.get("university"),
                "university_short": ranking.get("university_short"),
                "region": ranking.get("region"),
                "state": ranking.get("state")
            }
        }
        
        # Add regional ranking if available
        if has_regional:
            response["regional_ranking"] = {
                "rank_in_region": ranking.get("regional_rank"),
                "total_users_in_region": ranking.get("total_regional_users"),  # Fixed field name
                "percentile_region": ranking.get("regional_percentile"),
                "region": ranking.get("region"),
                "state": ranking.get("state"),
                "overall_score": ranking.get("overall_score")
            }
            response["regional_percentile_text"] = f"Top {ranking.get('regional_percentile', 0):.1f}% in {ranking.get('region', 'Unknown')}"
        
        # Add university ranking if available
        if has_university:
            response["university_ranking"] = {
                "rank_in_university": ranking.get("university_rank"),
                "total_users_in_university": ranking.get("total_university_users"),  # Fixed field name
                "percentile_university": ranking.get("university_percentile"),
                "university": ranking.get("university"),
                "university_short": ranking.get("university_short"),
                "overall_score": ranking.get("overall_score")
            }
            response["university_percentile_text"] = f"Top {ranking.get('university_percentile', 0):.1f}% in {ranking.get('university', 'Unknown')}"
        
        logger.info(f"✅ Ranking data found for {github_username}: Regional={has_regional}, University={has_university}")
        
        return response
        
    except Exception as e:
        logger.error(f"Failed to check ranking availability for {github_username}: {e}")
        return {
            "has_ranking_data": False,
            "message": f"Error checking ranking data: {str(e)}"
        }
