"""
HR Data Handler Service
Handles HR data detection, routing, and storage with backup replication
"""

import logging
from typing import Dict, Any, Optional, List, Union
from datetime import datetime
import asyncio
from bson import ObjectId

from app.db_connection_multi import (
    multi_db_manager,
    DatabaseType,
    get_raseen_main_hr_db,
    get_srie_main_hr_db
)

logger = logging.getLogger(__name__)

class HRDataType:
    """Constants for HR data types"""
    CANDIDATE_PROFILE = "candidate_profile"
    HR_USER = "hr_user"
    HR_REGISTRATION = "hr_registration"
    APPROVED_HR_USER = "approved_hr_user"
    CANDIDATE_EVALUATION = "candidate_evaluation"
    RECRUITMENT_INSIGHTS = "recruitment_insights"

class HRDataHandler:
    """Handles HR data operations with dedicated databases and backup replication"""
    
    def __init__(self):
        self.hr_collections = {
            HRDataType.CANDIDATE_PROFILE: "hr_candidate_profiles",
            HRDataType.HR_USER: "hr_users",
            HRDataType.HR_REGISTRATION: "hr_registrations", 
            HRDataType.APPROVED_HR_USER: "approved_hr_users",
            HRDataType.CANDIDATE_EVALUATION: "candidate_evaluations",
            HRDataType.RECRUITMENT_INSIGHTS: "recruitment_insights"
        }
    
    @staticmethod
    def is_hr_data(data: Dict[str, Any], operation_context: Optional[str] = None) -> bool:
        """
        Detect if data is HR-related based on content and context
        
        Args:
            data: Data dictionary to analyze
            operation_context: Optional context about the operation (e.g., "hr_dashboard", "candidate_search")
            
        Returns:
            bool: True if data is HR-related
        """
        try:
            # Check operation context first
            if operation_context:
                hr_contexts = [
                    "hr_dashboard", "hr_auth", "candidate_search", "candidate_profile",
                    "recruitment", "hr_registration", "hr_user", "candidate_evaluation"
                ]
                if any(context in operation_context.lower() for context in hr_contexts):
                    logger.debug(f"🏢 HR data detected from context: {operation_context}")
                    return True
            
            # Check data structure for HR-specific fields
            hr_indicators = [
                # HR User fields
                "google_id", "company", "role", "is_approved", "email_verified",
                # Candidate fields
                "candidate_id", "evaluation_score", "interview_notes", "recruitment_status",
                # HR Registration fields
                "contact_info", "reviewed", "approved", "reviewed_by",
                # General HR fields
                "hr_", "recruitment_", "candidate_", "interview_", "evaluation_"
            ]
            
            # Check if any HR indicators are present in the data
            data_str = str(data).lower()
            for indicator in hr_indicators:
                if indicator in data_str:
                    logger.debug(f"🏢 HR data detected from field: {indicator}")
                    return True
            
            # Check specific data patterns
            if isinstance(data, dict):
                # Check for HR user patterns
                if ("email" in data and "google_id" in data) or ("company" in data and "role" in data):
                    logger.debug("🏢 HR data detected from HR user pattern")
                    return True
                
                # Check for candidate evaluation patterns
                if "overall_score" in data and ("upvotes" in data or "repositories_count" in data):
                    logger.debug("🏢 HR data detected from candidate pattern")
                    return True
            
            return False
            
        except Exception as e:
            logger.warning(f"Error in HR data detection: {e}")
            return False
    
    @staticmethod
    def get_hr_data_type(data: Dict[str, Any], operation_context: Optional[str] = None) -> str:
        """
        Determine the specific type of HR data
        
        Args:
            data: Data dictionary to analyze
            operation_context: Optional context about the operation
            
        Returns:
            str: HR data type constant
        """
        try:
            if operation_context:
                if "hr_user" in operation_context.lower():
                    return HRDataType.HR_USER
                elif "hr_registration" in operation_context.lower():
                    return HRDataType.HR_REGISTRATION
                elif "approved_hr_user" in operation_context.lower():
                    return HRDataType.APPROVED_HR_USER
                elif "candidate_evaluation" in operation_context.lower():
                    return HRDataType.CANDIDATE_EVALUATION
                elif "candidate_profile" in operation_context.lower():
                    return HRDataType.CANDIDATE_PROFILE
                elif "recruitment_insights" in operation_context.lower():
                    return HRDataType.RECRUITMENT_INSIGHTS
            
            # Analyze data structure
            if isinstance(data, dict):
                if "google_id" in data and "email" in data:
                    return HRDataType.HR_USER
                elif "reviewed" in data and "approved" in data:
                    return HRDataType.HR_REGISTRATION
                elif "approved_by" in data and "approved_at" in data:
                    return HRDataType.APPROVED_HR_USER
                elif "evaluation_score" in data or "interview_notes" in data:
                    return HRDataType.CANDIDATE_EVALUATION
                elif "overall_score" in data and "repositories_count" in data:
                    return HRDataType.CANDIDATE_PROFILE
                elif "total_candidates" in data or "average_score" in data:
                    return HRDataType.RECRUITMENT_INSIGHTS
            
            # Default to candidate profile for general HR data
            return HRDataType.CANDIDATE_PROFILE
            
        except Exception as e:
            logger.warning(f"Error determining HR data type: {e}")
            return HRDataType.CANDIDATE_PROFILE
    
    async def store_hr_data(
        self, 
        data: Dict[str, Any], 
        hr_data_type: Optional[str] = None,
        operation_context: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Store HR data in raseen_main_hr with backup to srie_main_hr
        
        Args:
            data: HR data to store
            hr_data_type: Optional specific HR data type
            operation_context: Optional context about the operation
            
        Returns:
            Dict containing storage results and metadata
        """
        try:
            # Determine HR data type if not provided
            if not hr_data_type:
                hr_data_type = self.get_hr_data_type(data, operation_context)
            
            # Get collection name
            collection_name = self.hr_collections.get(hr_data_type, "hr_general_data")
            
            # Add metadata
            storage_data = {
                **data,
                "hr_data_type": hr_data_type,
                "stored_at": datetime.utcnow(),
                "storage_location": "RASEEN_MAIN_HR",
                "backup_status": "pending"
            }
            
            # Ensure document has an ID
            if "_id" not in storage_data:
                storage_data["_id"] = ObjectId()
            
            logger.info(f"🏢 [HR_STORAGE] Storing {hr_data_type} data to {collection_name}")
            
            # Store in primary HR database (raseen_main_hr)
            primary_result = await self._store_to_primary_hr_db(storage_data, collection_name)
            
            # Store backup in srie_main_hr
            backup_result = await self._store_to_backup_hr_db(storage_data, collection_name)
            
            # Update backup status
            if backup_result["success"]:
                storage_data["backup_status"] = "completed"
                await self._update_backup_status(storage_data["_id"], collection_name, "completed")
            else:
                storage_data["backup_status"] = "failed"
                await self._update_backup_status(storage_data["_id"], collection_name, "failed")
            
            result = {
                "success": primary_result["success"],
                "document_id": str(storage_data["_id"]),
                "hr_data_type": hr_data_type,
                "collection": collection_name,
                "primary_storage": primary_result,
                "backup_storage": backup_result,
                "backup_status": storage_data["backup_status"]
            }
            
            if primary_result["success"]:
                logger.info(f"✅ [HR_STORAGE] Successfully stored {hr_data_type} with ID: {storage_data['_id']}")
            else:
                logger.error(f"❌ [HR_STORAGE] Failed to store {hr_data_type}: {primary_result.get('error')}")
            
            return result
            
        except Exception as e:
            error_msg = f"error in storing to raseen_main_hr: {str(e)}"
            logger.error(f"❌ [HR_STORAGE] {error_msg}")
            return {
                "success": False,
                "error": error_msg,
                "hr_data_type": hr_data_type,
                "collection": collection_name if 'collection_name' in locals() else "unknown"
            }
    
    async def _store_to_primary_hr_db(self, data: Dict[str, Any], collection_name: str) -> Dict[str, Any]:
        """Store data to primary HR database (raseen_main_hr)"""
        try:
            async def store_operation(database):
                collection = database[collection_name]
                result = await collection.insert_one(data)
                return {"inserted_id": str(result.inserted_id)}
            
            result = await multi_db_manager.safe_db_operation(
                DatabaseType.RASEEN_MAIN_HR,
                store_operation,
                fallback_result=None,
                operation_name=f"storing to {collection_name}"
            )
            
            if result is not None:
                logger.debug(f"🏢 [PRIMARY_HR] Stored to {collection_name}: {result['inserted_id']}")
                return {"success": True, "inserted_id": result["inserted_id"]}
            else:
                return {"success": False, "error": "Primary storage operation failed"}
                
        except Exception as e:
            error_msg = f"error in storing to raseen_main_hr.{collection_name}: {str(e)}"
            logger.error(f"❌ [PRIMARY_HR] {error_msg}")
            return {"success": False, "error": error_msg}
    
    async def _store_to_backup_hr_db(self, data: Dict[str, Any], collection_name: str) -> Dict[str, Any]:
        """Store data to backup HR database (srie_main_hr)"""
        try:
            async def backup_operation(database):
                collection = database[collection_name]
                result = await collection.insert_one(data)
                return {"inserted_id": str(result.inserted_id)}
            
            result = await multi_db_manager.safe_db_operation(
                DatabaseType.SRIE_MAIN_HR,
                backup_operation,
                fallback_result=None,
                operation_name=f"backup to {collection_name}"
            )
            
            if result is not None:
                logger.debug(f"🏢 [BACKUP_HR] Backed up to {collection_name}: {result['inserted_id']}")
                return {"success": True, "inserted_id": result["inserted_id"]}
            else:
                return {"success": False, "error": "Backup storage operation failed"}
                
        except Exception as e:
            error_msg = f"error in storing to srie_main_hr.{collection_name}: {str(e)}"
            logger.warning(f"⚠️ [BACKUP_HR] {error_msg}")
            return {"success": False, "error": error_msg}
    
    async def _update_backup_status(self, document_id: ObjectId, collection_name: str, status: str):
        """Update backup status in primary database"""
        try:
            async def update_operation(database):
                collection = database[collection_name]
                result = await collection.update_one(
                    {"_id": document_id},
                    {"$set": {"backup_status": status, "backup_updated_at": datetime.utcnow()}}
                )
                return {"modified_count": result.modified_count}
            
            await multi_db_manager.safe_db_operation(
                DatabaseType.RASEEN_MAIN_HR,
                update_operation,
                fallback_result=None,
                operation_name=f"updating backup status in {collection_name}"
            )
            
        except Exception as e:
            logger.warning(f"Failed to update backup status: {e}")
    
    async def retrieve_hr_data(
        self, 
        query: Dict[str, Any], 
        collection_name: Optional[str] = None,
        hr_data_type: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Retrieve HR data from raseen_main_hr database
        
        Args:
            query: MongoDB query to execute
            collection_name: Optional specific collection name
            hr_data_type: Optional HR data type to determine collection
            
        Returns:
            List of matching documents
        """
        try:
            # Determine collection name
            if not collection_name:
                if hr_data_type:
                    collection_name = self.hr_collections.get(hr_data_type, "hr_general_data")
                else:
                    collection_name = "hr_general_data"
            
            logger.debug(f"🏢 [HR_RETRIEVAL] Querying {collection_name} with: {query}")
            
            async def retrieve_operation(database):
                collection = database[collection_name]
                cursor = collection.find(query)
                documents = await cursor.to_list(length=None)
                return documents
            
            result = await multi_db_manager.safe_db_operation(
                DatabaseType.RASEEN_MAIN_HR,
                retrieve_operation,
                fallback_result=[],
                operation_name=f"retrieving from {collection_name}"
            )
            
            logger.debug(f"🏢 [HR_RETRIEVAL] Found {len(result)} documents in {collection_name}")
            return result
            
        except Exception as e:
            error_msg = f"error in fetching from raseen_main_hr.{collection_name}: {str(e)}"
            logger.error(f"❌ [HR_RETRIEVAL] {error_msg}")
            return []
    
    async def update_hr_data(
        self, 
        query: Dict[str, Any], 
        update_data: Dict[str, Any],
        collection_name: Optional[str] = None,
        hr_data_type: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Update HR data in both primary and backup databases
        
        Args:
            query: MongoDB query to find documents to update
            update_data: Update operations to apply
            collection_name: Optional specific collection name
            hr_data_type: Optional HR data type to determine collection
            
        Returns:
            Dict containing update results
        """
        try:
            # Determine collection name
            if not collection_name:
                if hr_data_type:
                    collection_name = self.hr_collections.get(hr_data_type, "hr_general_data")
                else:
                    collection_name = "hr_general_data"
            
            # Add update metadata
            update_operations = {
                **update_data,
                "$set": {
                    **update_data.get("$set", {}),
                    "updated_at": datetime.utcnow()
                }
            }
            
            logger.info(f"🏢 [HR_UPDATE] Updating {collection_name} with query: {query}")
            
            # Update primary database
            primary_result = await self._update_primary_hr_db(query, update_operations, collection_name)
            
            # Update backup database
            backup_result = await self._update_backup_hr_db(query, update_operations, collection_name)
            
            result = {
                "success": primary_result["success"],
                "collection": collection_name,
                "primary_update": primary_result,
                "backup_update": backup_result
            }
            
            if primary_result["success"]:
                logger.info(f"✅ [HR_UPDATE] Successfully updated {collection_name}")
            else:
                logger.error(f"❌ [HR_UPDATE] Failed to update {collection_name}: {primary_result.get('error')}")
            
            return result
            
        except Exception as e:
            error_msg = f"error in updating raseen_main_hr.{collection_name}: {str(e)}"
            logger.error(f"❌ [HR_UPDATE] {error_msg}")
            return {
                "success": False,
                "error": error_msg,
                "collection": collection_name if 'collection_name' in locals() else "unknown"
            }
    
    async def _update_primary_hr_db(self, query: Dict[str, Any], update_data: Dict[str, Any], collection_name: str) -> Dict[str, Any]:
        """Update data in primary HR database"""
        try:
            async def update_operation(database):
                collection = database[collection_name]
                result = await collection.update_many(query, update_data)
                return {"modified_count": result.modified_count, "matched_count": result.matched_count}
            
            result = await multi_db_manager.safe_db_operation(
                DatabaseType.RASEEN_MAIN_HR,
                update_operation,
                fallback_result=None,
                operation_name=f"updating {collection_name}"
            )
            
            if result is not None:
                return {"success": True, **result}
            else:
                return {"success": False, "error": "Primary update operation failed"}
                
        except Exception as e:
            error_msg = f"error in updating raseen_main_hr.{collection_name}: {str(e)}"
            logger.error(f"❌ [PRIMARY_HR_UPDATE] {error_msg}")
            return {"success": False, "error": error_msg}
    
    async def _update_backup_hr_db(self, query: Dict[str, Any], update_data: Dict[str, Any], collection_name: str) -> Dict[str, Any]:
        """Update data in backup HR database"""
        try:
            async def update_operation(database):
                collection = database[collection_name]
                result = await collection.update_many(query, update_data)
                return {"modified_count": result.modified_count, "matched_count": result.matched_count}
            
            result = await multi_db_manager.safe_db_operation(
                DatabaseType.SRIE_MAIN_HR,
                update_operation,
                fallback_result=None,
                operation_name=f"backup update {collection_name}"
            )
            
            if result is not None:
                return {"success": True, **result}
            else:
                return {"success": False, "error": "Backup update operation failed"}
                
        except Exception as e:
            error_msg = f"error in updating srie_main_hr.{collection_name}: {str(e)}"
            logger.warning(f"⚠️ [BACKUP_HR_UPDATE] {error_msg}")
            return {"success": False, "error": error_msg}
    
    async def get_hr_collections_info(self) -> Dict[str, Any]:
        """Get information about HR collections in both databases"""
        try:
            primary_info = await self._get_database_collections_info(DatabaseType.RASEEN_MAIN_HR, "primary")
            backup_info = await self._get_database_collections_info(DatabaseType.SRIE_MAIN_HR, "backup")
            
            return {
                "primary_hr_database": primary_info,
                "backup_hr_database": backup_info,
                "available_collections": list(self.hr_collections.values()),
                "hr_data_types": list(self.hr_collections.keys())
            }
            
        except Exception as e:
            logger.error(f"Failed to get HR collections info: {e}")
            return {"error": str(e)}
    
    async def _get_database_collections_info(self, db_type: DatabaseType, db_label: str) -> Dict[str, Any]:
        """Get collection information for a specific database"""
        try:
            async def info_operation(database):
                collections = await database.list_collection_names()
                collection_stats = {}
                
                for collection_name in collections:
                    if collection_name.startswith("hr_") or collection_name in self.hr_collections.values():
                        try:
                            stats = await database.command("collStats", collection_name)
                            collection_stats[collection_name] = {
                                "count": stats.get("count", 0),
                                "size": stats.get("size", 0),
                                "avgObjSize": stats.get("avgObjSize", 0)
                            }
                        except:
                            collection_stats[collection_name] = {"count": 0, "size": 0, "avgObjSize": 0}
                
                return {
                    "total_collections": len(collections),
                    "hr_collections": len(collection_stats),
                    "collections": collection_stats
                }
            
            result = await multi_db_manager.safe_db_operation(
                db_type,
                info_operation,
                fallback_result={"error": f"Failed to get {db_label} database info"},
                operation_name=f"getting {db_label} collections info"
            )
            
            return result
            
        except Exception as e:
            return {"error": f"Failed to get {db_label} database info: {str(e)}"}

# Global instance
hr_data_handler = HRDataHandler()

# Convenience functions
async def store_hr_data(data: Dict[str, Any], hr_data_type: Optional[str] = None, operation_context: Optional[str] = None) -> Dict[str, Any]:
    """Convenience function to store HR data"""
    return await hr_data_handler.store_hr_data(data, hr_data_type, operation_context)

async def retrieve_hr_data(query: Dict[str, Any], collection_name: Optional[str] = None, hr_data_type: Optional[str] = None) -> List[Dict[str, Any]]:
    """Convenience function to retrieve HR data"""
    return await hr_data_handler.retrieve_hr_data(query, collection_name, hr_data_type)

async def update_hr_data(query: Dict[str, Any], update_data: Dict[str, Any], collection_name: Optional[str] = None, hr_data_type: Optional[str] = None) -> Dict[str, Any]:
    """Convenience function to update HR data"""
    return await hr_data_handler.update_hr_data(query, update_data, collection_name, hr_data_type)

def is_hr_data(data: Dict[str, Any], operation_context: Optional[str] = None) -> bool:
    """Convenience function to detect HR data"""
    return HRDataHandler.is_hr_data(data, operation_context)

def get_hr_data_type(data: Dict[str, Any], operation_context: Optional[str] = None) -> str:
    """Convenience function to get HR data type"""
    return HRDataHandler.get_hr_data_type(data, operation_context)

async def get_hr_collections_info() -> Dict[str, Any]:
    """Convenience function to get HR collections info"""
    return await hr_data_handler.get_hr_collections_info()