"""
Ranking service for regional and university comparisons.
Handles ranking calculations, percentile computation, and batch updates.
"""

import logging
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime
from motor.motor_asyncio import AsyncIOMotorDatabase
from pymongo import UpdateOne

logger = logging.getLogger(__name__)


class RankingService:
    """Service for calculating and managing user rankings"""
    
    def __init__(self, database: AsyncIOMotorDatabase):
        self.db = database
    
    # ========================================================================
    # Core Ranking Calculation Methods
    # ========================================================================
    
    def calculate_percentile(self, user_score: float, all_scores: List[float]) -> float:
        """
        Calculate percentile ranking where higher scores = better performance
        
        Formula: (users_with_lower_score / total_users) × 100
        
        Args:
            user_score: The user's ACID score
            all_scores: List of all scores in the comparison group
        
        Returns:
            Percentile (0-100) where 100 = top performer
        
        Edge cases handled:
        - Empty list: returns 0.0
        - Single user: returns 100.0 (top of their group)
        - Tied scores: all users with same score get same percentile
        """
        if not all_scores:
            logger.warning("Empty scores list provided to calculate_percentile")
            return 0.0
        
        if len(all_scores) == 1:
            return 100.0
        
        # Validate score range
        if not (0 <= user_score <= 100):
            logger.warning(f"Score {user_score} outside valid range [0, 100]")
            user_score = max(0, min(100, user_score))  # Clamp to valid range
        
        # Count users with strictly lower scores
        users_below = sum(1 for score in all_scores if score < user_score)
        
        # Calculate percentile
        percentile = (users_below / len(all_scores)) * 100
        
        return round(percentile, 1)
    
    def calculate_rank_position(self, user_score: float, all_scores: List[float]) -> int:
        """
        Calculate rank position (1 = best, N = worst)
        
        Tied scores get the same rank position.
        
        Args:
            user_score: The user's ACID score
            all_scores: List of all scores in the comparison group
        
        Returns:
            Rank position (1-indexed)
        """
        if not all_scores:
            return 1
        
        # Sort scores in descending order (highest first)
        sorted_scores = sorted(all_scores, reverse=True)
        
        # Count how many scores are strictly better than user's score
        rank = 1
        for score in sorted_scores:
            if score > user_score:
                rank += 1
            elif score == user_score:
                # Found the user's score, return current rank
                return rank
        
        return rank
    
    def validate_score(self, score: float) -> bool:
        """
        Validate that a score is within the valid range
        
        Args:
            score: ACID score to validate
        
        Returns:
            True if valid, False otherwise
        """
        return isinstance(score, (int, float)) and 0 <= score <= 100
    
    # ========================================================================
    # Regional Ranking Methods
    # ========================================================================
    
    async def update_regional_rankings(self, region: str) -> Dict[str, Any]:
        """
        Recalculate rankings for all users in a specific region
        
        Args:
            region: Region identifier (e.g., "US-California")
        
        Returns:
            Dictionary with update statistics
        """
        try:
            logger.info(f"Updating regional rankings for region: {region}")
            
            # Fetch all users in region with their scores, sorted by score descending
            users = await self.db.regional_scores.find(
                {"region": region}
            ).sort("acid_score", -1).to_list(None)
            
            if not users:
                logger.warning(f"No users found in region: {region}")
                return {
                    "success": True,
                    "region": region,
                    "users_updated": 0,
                    "message": "No users in region"
                }
            
            total_users = len(users)
            all_scores = [u["acid_score"] for u in users]
            
            logger.info(f"Found {total_users} users in region {region}")
            
            # Prepare batch update operations
            bulk_operations = []
            
            for user in users:
                percentile = self.calculate_percentile(user["acid_score"], all_scores)
                rank = self.calculate_rank_position(user["acid_score"], all_scores)
                
                bulk_operations.append(
                    UpdateOne(
                        {"user_id": user["user_id"]},
                        {
                            "$set": {
                                "percentile_score": percentile,
                                "rank_position": rank,
                                "total_users_in_region": total_users,
                                "last_updated": datetime.utcnow()
                            }
                        }
                    )
                )
            
            # Execute batch update
            if bulk_operations:
                result = await self.db.regional_scores.bulk_write(bulk_operations)
                logger.info(f"Updated {result.modified_count} regional rankings for {region}")
                
                return {
                    "success": True,
                    "region": region,
                    "users_updated": result.modified_count,
                    "total_users": total_users
                }
            
            return {
                "success": True,
                "region": region,
                "users_updated": 0,
                "total_users": total_users
            }
            
        except Exception as e:
            logger.error(f"Error updating regional rankings for {region}: {e}")
            return {
                "success": False,
                "region": region,
                "error": str(e)
            }
    
    async def get_regional_ranking(self, user_id: str) -> Optional[Dict[str, Any]]:
        """
        Get regional ranking for a specific user
        
        Args:
            user_id: User identifier
        
        Returns:
            Dictionary with ranking information or None
        """
        try:
            ranking = await self.db.regional_scores.find_one({"user_id": user_id})
            
            if ranking:
                # Remove MongoDB _id for cleaner response
                ranking.pop("_id", None)
                return ranking
            
            return None
            
        except Exception as e:
            logger.error(f"Error getting regional ranking for user {user_id}: {e}")
            return None
    
    # ========================================================================
    # University Ranking Methods
    # ========================================================================
    
    async def update_university_rankings(self, university_short: str) -> Dict[str, Any]:
        """
        Recalculate rankings for all users in a specific university
        
        Args:
            university_short: University short identifier (e.g., "mit")
        
        Returns:
            Dictionary with update statistics
        """
        try:
            logger.info(f"Updating university rankings for: {university_short}")
            
            # Fetch all users in university with their scores, sorted by score descending
            users = await self.db.university_scores.find(
                {"university_short": university_short}
            ).sort("acid_score", -1).to_list(None)
            
            if not users:
                logger.warning(f"No users found in university: {university_short}")
                return {
                    "success": True,
                    "university_short": university_short,
                    "users_updated": 0,
                    "message": "No users in university"
                }
            
            total_users = len(users)
            all_scores = [u["acid_score"] for u in users]
            
            logger.info(f"Found {total_users} users in university {university_short}")
            
            # Prepare batch update operations
            bulk_operations = []
            
            for user in users:
                percentile = self.calculate_percentile(user["acid_score"], all_scores)
                rank = self.calculate_rank_position(user["acid_score"], all_scores)
                
                bulk_operations.append(
                    UpdateOne(
                        {"user_id": user["user_id"]},
                        {
                            "$set": {
                                "percentile_score": percentile,
                                "rank_position": rank,
                                "total_users_in_university": total_users,
                                "last_updated": datetime.utcnow()
                            }
                        }
                    )
                )
            
            # Execute batch update
            if bulk_operations:
                result = await self.db.university_scores.bulk_write(bulk_operations)
                logger.info(f"Updated {result.modified_count} university rankings for {university_short}")
                
                return {
                    "success": True,
                    "university_short": university_short,
                    "users_updated": result.modified_count,
                    "total_users": total_users
                }
            
            return {
                "success": True,
                "university_short": university_short,
                "users_updated": 0,
                "total_users": total_users
            }
            
        except Exception as e:
            logger.error(f"Error updating university rankings for {university_short}: {e}")
            return {
                "success": False,
                "university_short": university_short,
                "error": str(e)
            }
    
    async def get_university_ranking(self, user_id: str) -> Optional[Dict[str, Any]]:
        """
        Get university ranking for a specific user
        
        Args:
            user_id: User identifier
        
        Returns:
            Dictionary with ranking information or None
        """
        try:
            ranking = await self.db.university_scores.find_one({"user_id": user_id})
            
            if ranking:
                # Remove MongoDB _id for cleaner response
                ranking.pop("_id", None)
                return ranking
            
            return None
            
        except Exception as e:
            logger.error(f"Error getting university ranking for user {user_id}: {e}")
            return None
    
    # ========================================================================
    # Combined Ranking Methods
    # ========================================================================
    
    async def get_user_rankings(self, user_id: str) -> Dict[str, Any]:
        """
        Get both regional and university rankings for a user
        
        Args:
            user_id: User identifier
        
        Returns:
            Dictionary with both rankings
        """
        regional = await self.get_regional_ranking(user_id)
        university = await self.get_university_ranking(user_id)
        
        return {
            "user_id": user_id,
            "regional_ranking": regional,
            "university_ranking": university,
            "has_regional": regional is not None,
            "has_university": university is not None
        }
    
    async def update_all_rankings_for_user(self, user_id: str) -> Dict[str, Any]:
        """
        Update both regional and university rankings for a user
        
        This triggers batch updates for all users in the same region and university.
        
        Args:
            user_id: User identifier
        
        Returns:
            Dictionary with update results
        """
        try:
            # Get user profile to find region and university
            profile = await self.db.user_profiles.find_one({"user_id": user_id})
            
            if not profile:
                return {
                    "success": False,
                    "error": "User profile not found"
                }
            
            region = profile.get("region")
            university_short = profile.get("university_short")
            
            results = {
                "success": True,
                "user_id": user_id,
                "regional_update": None,
                "university_update": None
            }
            
            # Update regional rankings
            if region:
                results["regional_update"] = await self.update_regional_rankings(region)
            
            # Update university rankings
            if university_short:
                results["university_update"] = await self.update_university_rankings(university_short)
            
            return results
            
        except Exception as e:
            logger.error(f"Error updating all rankings for user {user_id}: {e}")
            return {
                "success": False,
                "user_id": user_id,
                "error": str(e)
            }
    
    # ========================================================================
    # Leaderboard Methods
    # ========================================================================
    
    async def get_regional_leaderboard(self, region: str, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get top users in a region
        
        Args:
            region: Region identifier
            limit: Number of top users to return
        
        Returns:
            List of top users with their rankings
        """
        try:
            leaderboard = await self.db.regional_scores.find(
                {"region": region}
            ).sort("rank_position", 1).limit(limit).to_list(None)
            
            # Remove MongoDB _id and sensitive data
            for entry in leaderboard:
                entry.pop("_id", None)
            
            return leaderboard
            
        except Exception as e:
            logger.error(f"Error getting regional leaderboard for {region}: {e}")
            return []
    
    async def get_university_leaderboard(self, university_short: str, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get top users in a university
        
        Args:
            university_short: University short identifier
            limit: Number of top users to return
        
        Returns:
            List of top users with their rankings
        """
        try:
            leaderboard = await self.db.university_scores.find(
                {"university_short": university_short}
            ).sort("rank_position", 1).limit(limit).to_list(None)
            
            # Remove MongoDB _id and sensitive data
            for entry in leaderboard:
                entry.pop("_id", None)
            
            return leaderboard
            
        except Exception as e:
            logger.error(f"Error getting university leaderboard for {university_short}: {e}")
            return []
