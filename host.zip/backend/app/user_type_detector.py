"""
User Type Detection and Database Routing System
Handles identification of internal vs external users based on JWT authentication status
and routes them to appropriate databases
"""

from typing import Optional, Dict, Any, Literal, Union
from fastapi import Request, HTTPException
from app.db_connection_multi import (
    multi_db_manager, 
    DatabaseType,
    get_external_users_db,
    get_raseen_temp_user_db,
    get_raseen_main_user_db,
    get_raseen_main_hr_db
)
from app.core.security import get_current_user_optional
from app.services.hr_data_handler import is_hr_data, get_hr_data_type
import logging
from bson import ObjectId

logger = logging.getLogger(__name__)

UserType = Literal["internal", "external"]
DataCategory = Literal["user_data", "hr_data", "scan_cache", "analysis_progress"]

class UserTypeDetector:
    """Detects user type based on JWT authentication status and provides appropriate database routing"""
    
    @staticmethod
    async def detect_user_type(request: Request, username: Optional[str] = None) -> UserType:
        """
        Detect user type based purely on JWT authentication status
        
        Args:
            request: FastAPI request object
            username: Optional username (for logging purposes only)
            
        Returns:
            UserType: "internal" if JWT token is present and valid, "external" otherwise
        """
        try:
            # Try to get current user from JWT token
            current_user = await get_current_user_optional(request)
            
            if current_user is not None:
                logger.debug(f"🔐 Detected internal user: {current_user.email}")
                return "internal"
            
            logger.debug(f"🌐 Detected external user: {username or 'anonymous'}")
            return "external"
                
        except Exception as e:
            logger.debug(f"Authentication failed, treating as external user: {e}")
            return "external"
    
    @staticmethod
    def get_user_id_with_prefix(user_data: Union[str, Dict[str, Any]], user_type: UserType) -> str:
        """
        Generate user ID with appropriate prefix based on user type
        
        Args:
            user_data: User data (username string for external, user object for internal)
            user_type: Type of user ("internal" or "external")
            
        Returns:
            str: User ID without prefix (temporarily)
        """
        # TEMPORARY: Return username without any prefix for ALL users
        # TODO: Restore proper prefix logic later
        if user_type == "internal":
            # For internal users, try to get username from user object
            if isinstance(user_data, dict):
                username = user_data.get("username", user_data.get("login", user_data.get("email", "")))
            elif hasattr(user_data, 'username'):
                username = user_data.username
            elif hasattr(user_data, 'email'):
                username = user_data.email.split('@')[0] if user_data.email else str(user_data.id)
            else:
                username = str(user_data)
            return username
        else:  # external
            # For external users, use username directly
            if isinstance(user_data, dict):
                username = user_data.get("username", user_data.get("login", ""))
            elif hasattr(user_data, 'username'):
                username = user_data.username
            else:
                username = str(user_data)
            return username
        
        # COMMENTED OUT - Original prefix logic (restore later)
        # if user_type == "internal":
        #     # For internal users, use ObjectId from user object
        #     if isinstance(user_data, dict):
        #         user_id = str(user_data.get("id", user_data.get("_id", "")))
        #     elif hasattr(user_data, 'id'):
        #         user_id = str(user_data.id)
        #     else:
        #         user_id = str(user_data)
        #     
        #     # Ensure it's a valid ObjectId format
        #     try:
        #         ObjectId(user_id)
        #         return f"internal_{user_id}"
        #     except:
        #         # If not valid ObjectId, create one
        #         new_id = str(ObjectId())
        #         logger.warning(f"Invalid ObjectId for internal user, generated new: {new_id}")
        #         return f"internal_{new_id}"
        # 
        # else:  # external
        #     # For external users, use username directly
        #     if isinstance(user_data, dict):
        #         username = user_data.get("username", user_data.get("login", ""))
        #     elif hasattr(user_data, 'username'):
        #         username = user_data.username
        #     else:
        #         username = str(user_data)
        #     
        #     return f"external_{username}"
    
    @staticmethod
    async def get_appropriate_database(user_type: UserType, data_category: DataCategory = "user_data", data: Optional[Dict[str, Any]] = None, operation_context: Optional[str] = None):
        """
        Get the appropriate database based on user type, data category, and HR data detection
        
        Args:
            user_type: Type of user ("internal" or "external")
            data_category: Category of data being stored
            data: Optional data to analyze for HR content
            operation_context: Optional context about the operation
            
        Returns:
            Database instance for the appropriate database
        """
        try:
            # TEMPORARY: Route ALL users to external_users database for now
            # TODO: Restore proper routing logic later
            logger.debug(f"🔄 [TEMPORARY] Routing {user_type} user to external_users database")
            return await get_external_users_db()
            
            # COMMENTED OUT - Original routing logic (restore later)
            # # Check if this is HR data regardless of user type
            # if data and is_hr_data(data, operation_context):
            #     logger.debug("🏢 Routing to raseen_main_hr database (HR data detected)")
            #     return await get_raseen_main_hr_db()
            # 
            # if user_type == "external":
            #     # External users always go to external_users database (unless HR data)
            #     logger.debug("🌐 Routing to external_users database")
            #     return await get_external_users_db()
            # 
            # elif user_type == "internal":
            #     if data_category == "hr_data":
            #         # Explicit HR data goes to HR database
            #         logger.debug("🔐 Routing to raseen_main_hr database (explicit HR category)")
            #         return await get_raseen_main_hr_db()
            #     else:
            #         # Regular internal user data goes to temp database initially
            #         logger.debug("🔐 Routing to raseen_temp_user database")
            #         return await get_raseen_temp_user_db()
            # 
            # else:
            #     raise ValueError(f"Unknown user type: {user_type}")
                
        except Exception as e:
            error_msg = f"error in fetching database for user_type={user_type}, data_category={data_category}: {e}"
            logger.error(error_msg)
            raise HTTPException(status_code=500, detail=error_msg)
    
    @staticmethod
    def get_collection_name(base_collection: str, user_type: UserType) -> str:
        """
        Get collection name with appropriate prefix based on user type
        
        Args:
            base_collection: Base collection name (e.g., "scan_cache", "analysis_progress")
            user_type: Type of user ("internal" or "external")
            
        Returns:
            str: Prefixed collection name
        """
        # TEMPORARY: Use external_scan_cache for ALL users (no prefixes)
        # TODO: Restore proper collection naming later
        if base_collection == "scan_cache":
            return "external_scan_cache"
        elif base_collection == "analysis_progress":
            return "external_analysis_progress"
        else:
            return f"external_{base_collection}"
        
        # COMMENTED OUT - Original collection naming logic (restore later)
        # if user_type == "internal":
        #     return f"internal_{base_collection}"
        # else:
        #     return f"external_{base_collection}"
    
    @staticmethod
    async def route_user_operation(request: Request, username: str, operation_type: str = "scan", data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Complete user routing that detects type and provides all necessary routing information
        
        Args:
            request: FastAPI request object
            username: Username for the operation
            operation_type: Type of operation being performed
            data: Optional data to analyze for HR content
            
        Returns:
            Dict containing user_type, user_id, database, and collection info
        """
        try:
            # Detect user type based on JWT authentication
            user_type = await UserTypeDetector.detect_user_type(request, username)
            
            # Check if this is HR data
            is_hr_operation = data and is_hr_data(data, operation_type)
            hr_data_type = get_hr_data_type(data, operation_type) if is_hr_operation else None
            
            # Generate appropriate user ID
            if user_type == "internal":
                # For internal users, get the actual user object
                current_user = await get_current_user_optional(request)
                user_id = UserTypeDetector.get_user_id_with_prefix(current_user, user_type)
            else:
                # For external users, use the username
                user_id = UserTypeDetector.get_user_id_with_prefix(username, user_type)
            
            # Get appropriate database (with HR data detection)
            database = await UserTypeDetector.get_appropriate_database(user_type, "user_data", data, operation_type)
            
            # Get collection names
            if is_hr_operation:
                # HR operations use HR-specific collections
                scan_collection = f"hr_{hr_data_type}_cache"
                analysis_collection = f"hr_{hr_data_type}_progress"
                storage_location = "HR_DATABASE"
            else:
                # TEMPORARY: All operations use external collections (no prefixes)
                scan_collection = UserTypeDetector.get_collection_name("scan_cache", user_type)
                analysis_collection = UserTypeDetector.get_collection_name("analysis_progress", user_type)
                storage_location = "EXTERNAL_DATABASE"  # All users go to external DB temporarily
            
            routing_info = {
                "user_type": user_type,
                "user_id": user_id,
                "username": username,
                "database": database,
                "scan_collection": scan_collection,
                "analysis_collection": analysis_collection,
                "storage_location": storage_location,
                "is_hr_operation": is_hr_operation,
                "hr_data_type": hr_data_type
            }
            
            # Log routing decision
            if is_hr_operation:
                logger.info(f"🏢 [HR_ROUTING] User: {username} -> {user_id}")
                logger.info(f"🏢 [HR_ROUTING] Database: raseen_main_hr")
                logger.info(f"🏢 [HR_ROUTING] HR Data Type: {hr_data_type}")
                logger.info(f"🏢 [HR_ROUTING] Collections: {scan_collection}, {analysis_collection}")
            else:
                # TEMPORARY: All users go to external_users database
                logger.info(f"🔄 [TEMPORARY_ROUTING] User Type: {user_type}, User: {username} -> {user_id}")
                logger.info(f"🔄 [TEMPORARY_ROUTING] Database: external_users (ALL USERS)")
                logger.info(f"🔄 [TEMPORARY_ROUTING] Collections: {scan_collection}, {analysis_collection}")
                
                # COMMENTED OUT - Original routing logs (restore later)
                # elif user_type == "internal":
                #     logger.info(f"🔐 [INTERNAL_ROUTING] User: {username} -> {user_id}")
                #     logger.info(f"🔐 [INTERNAL_ROUTING] Database: raseen_temp_user")
                #     logger.info(f"🔐 [INTERNAL_ROUTING] Collections: {scan_collection}, {analysis_collection}")
                # else:
                #     logger.info(f"🌐 [EXTERNAL_ROUTING] User: {username} -> {user_id}")
                #     logger.info(f"🌐 [EXTERNAL_ROUTING] Database: external_users")
                #     logger.info(f"🌐 [EXTERNAL_ROUTING] Collections: {scan_collection}, {analysis_collection}")
            
            return routing_info
            
        except Exception as e:
            error_msg = f"error in routing user operation for {username}: {e}"
            logger.error(error_msg)
            raise HTTPException(status_code=500, detail=error_msg)

# Convenience functions for common operations
async def detect_user_type_from_request(request: Request, username: Optional[str] = None) -> UserType:
    """Convenience function to detect user type from request"""
    return await UserTypeDetector.detect_user_type(request, username)

async def get_user_database(request: Request, data_category: DataCategory = "user_data", data: Optional[Dict[str, Any]] = None, operation_context: Optional[str] = None, username: Optional[str] = None):
    """Convenience function to get appropriate database for user"""
    user_type = await UserTypeDetector.detect_user_type(request, username)
    return await UserTypeDetector.get_appropriate_database(user_type, data_category, data, operation_context)

def create_prefixed_user_id(user_data: Union[str, Dict[str, Any]], user_type: UserType) -> str:
    """Convenience function to create prefixed user ID"""
    return UserTypeDetector.get_user_id_with_prefix(user_data, user_type)

def get_prefixed_collection_name(base_collection: str, user_type: UserType) -> str:
    """Convenience function to get prefixed collection name"""
    return UserTypeDetector.get_collection_name(base_collection, user_type)