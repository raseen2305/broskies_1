"""
Tests for the scoring system
"""
