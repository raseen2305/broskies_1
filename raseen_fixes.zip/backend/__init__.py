"""
BroskiesHub Backend Package

This package contains the FastAPI backend application for the BroskiesHub
GitHub repository evaluation system.
"""

__version__ = "1.0.0"
__author__ = "BroskiesHub Team"