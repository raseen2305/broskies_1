"""
GitHub Developer Scoring System
Two-stage scoring system with instant feedback and deep analysis
"""

__version__ = "1.0.0"
